
import sys
import tensorflow as tf
print("Python:", sys.version)
print("TensorFlow:", tf.__version__)
import numpy as np, pandas as pd, sklearn
print("numpy:", np.__version__, "pandas:", pd.__version__, "sklearn:", sklearn.__version__)
