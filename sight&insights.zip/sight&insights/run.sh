#!/bin/bash
# Simple wrapper to run the main script after setting python env
python3 sight_and_insights.py
